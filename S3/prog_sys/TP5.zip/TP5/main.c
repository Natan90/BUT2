//gcc -g -Og -Wall -Wextra main.c -o tp5
//./main
//.tp5 ls
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <signal.h>

int mon_system(const char *command) {
    if (!command) return 1;
    pid_t pid = fork();
    if (pid < 0) return -1;
    //Créer un fils

    if (pid == 0) {
        //MEt les signaux par défaut
        signal(SIGINT, SIG_DFL);
        signal(SIGQUIT, SIG_DFL);
        execl("/bin/sh", "sh", "-c", command, (char *)NULL);
        _exit(127);
    } else {
        //On est dans le pere donc on attend que le fils finisse
        int status;
        if (waitpid(pid, &status, 0) < 0) return -1;
        return status;
    }
}

int main(int argc, char *argv[]) {
    char command[1024];
    //Aucun argument ( ./tp5 par ex) donc on lance juste bash
    if (argc == 1) {
        snprintf(command, sizeof(command), "bash");
    } else {
        command[0] = '\0';
        for (int i = 1; i < argc; i++) {
            strcat(command, argv[i]);
            strcat(command, " ");
        }
    }
    //Lance xterm, -hold permet de le garder ouvert, -e c'est pour lancer le commande en meme temsp (ls par ex)
    char *xterm_args[] = {"xterm", "-hold", "-e", command, NULL};

    execvp("xterm", xterm_args);

    perror("execvp");
    return 1;
}